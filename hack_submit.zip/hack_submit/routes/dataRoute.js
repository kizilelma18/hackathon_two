const express = require("express");
const router = express.Router();
const Datas = require("../models/data");


router.get("/",(req,res)=>{
    Datas.find().then((data)=>{
        res.json(data);
    })
});



module.exports = router;