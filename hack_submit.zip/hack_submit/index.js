const cheerio = require("cheerio");
const axios = require("axios");
const express = require("express");
const mongoose= require("mongoose");
const PORT = 5000;
const app = express();
const Datas = require('./models/data');
const cors = require("cors");
const url = 'mongodb+srv://gok_boru3:Zeesha9@@cluster0.mamc9.mongodb.net/Zee';

mongoose.connect(url, { useNewUrlParser: true });
const con = mongoose.connection;
con.on("open", () => console.log("MongoDB is connected"));
app.use(express.json());
app.use(cors())
const url1 =
  "https://www.flipkart.com/realme-narzo-30a-laser-black-32-gb/p/itma78aeb1d764b5?pid=MOBGYFAXAUENZFU3&lid=LSTMOBGYFAXAUENZFU3JULWX9&marketplace=FLIPKART&q=mobiles&store=tyy%2F4io&srno=s_1_1&otracker=AS_Query_TrendingAutoSuggest_1_0_na_na_na&otracker1=AS_Query_TrendingAutoSuggest_1_0_na_na_na&fm=SEARCH&iid=1c53db33-e1b3-4f0e-81e5-b2dbc653d9ba.MOBGYFAXAUENZFU3.SEARCH&ppt=hp&ppn=homepage&ssid=p2znvphp0g0000001625504337360&qH=eb4af0bf07c16429";
const url2 =
  "https://www.flipkart.com/realme-c21-cross-black-64-gb/p/itmf4062d3f37c1a?pid=MOBGF489G9HRWFZ9&lid=LSTMOBGF489G9HRWFZ9BYFZCR&marketplace=FLIPKART&q=mobiles&store=tyy%2F4io&srno=s_1_3&otracker=AS_Query_TrendingAutoSuggest_1_0_na_na_na&otracker1=AS_Query_TrendingAutoSuggest_1_0_na_na_na&fm=SEARCH&iid=443f365f-c790-45d1-9cd7-046a18fde1ef.MOBGF489G9HRWFZ9.SEARCH&ppt=hp&ppn=homepage&ssid=qtape0o33k0000001625506569046&qH=eb4af0bf07c16429";
const url3 =
  "https://www.flipkart.com/poco-m3-cool-blue-64-gb/p/itmc8ec867cb0472?pid=MOBFZTCUDDCTDN3G&lid=LSTMOBFZTCUDDCTDN3GJBLKQ8&marketplace=FLIPKART&q=mobiles&store=tyy%2F4io&srno=s_1_7&otracker=AS_Query_TrendingAutoSuggest_1_0_na_na_na&otracker1=AS_Query_TrendingAutoSuggest_1_0_na_na_na&fm=SEARCH&iid=443f365f-c790-45d1-9cd7-046a18fde1ef.MOBFZTCUDDCTDN3G.SEARCH&ppt=hp&ppn=homepage&ssid=qtape0o33k0000001625506569046&qH=eb4af0bf07c16429";
const url4 =
  "https://www.flipkart.com/redmi-9i-midnight-black-64-gb/p/itm0e1018dac2627?pid=MOBFV8RYKWQ3HACE&lid=LSTMOBFV8RYKWQ3HACEV2QOWQ&marketplace=FLIPKART&q=mobiles&store=tyy%2F4io&srno=s_1_10&otracker=AS_Query_TrendingAutoSuggest_1_0_na_na_na&otracker1=AS_Query_TrendingAutoSuggest_1_0_na_na_na&fm=SEARCH&iid=443f365f-c790-45d1-9cd7-046a18fde1ef.MOBFV8RYKWQ3HACE.SEARCH&ppt=hp&ppn=homepage&ssid=qtape0o33k0000001625506569046&qH=eb4af0bf07c16429";
const url5 =
  "https://www.flipkart.com/realme-c20-cool-blue-32-gb/p/itmea1903897436b?pid=MOBGF4894MEWZJGV&lid=LSTMOBGF4894MEWZJGVW425N5&marketplace=FLIPKART&q=mobiles&store=tyy%2F4io&srno=s_1_11&otracker=AS_Query_TrendingAutoSuggest_1_0_na_na_na&otracker1=AS_Query_TrendingAutoSuggest_1_0_na_na_na&fm=SEARCH&iid=443f365f-c790-45d1-9cd7-046a18fde1ef.MOBGF4894MEWZJGV.SEARCH&ppt=hp&ppn=homepage&ssid=qtape0o33k0000001625506569046&qH=eb4af0bf07c16429";
const url6 =
  "https://www.flipkart.com/motorola-e7-power-tahiti-blue-32-gb/p/itma02602f17ee58?pid=MOBFVH62YREWQYFZ&lid=LSTMOBFVH62YREWQYFZHR6ETR&marketplace=FLIPKART&q=mobiles&store=tyy%2F4io&srno=s_1_24&otracker=AS_Query_TrendingAutoSuggest_1_0_na_na_na&otracker1=AS_Query_TrendingAutoSuggest_1_0_na_na_na&fm=SEARCH&iid=1c53db33-e1b3-4f0e-81e5-b2dbc653d9ba.MOBFVH62YREWQYFZ.SEARCH&ppt=hp&ppn=homepage&ssid=p2znvphp0g0000001625504337360&qH=eb4af0bf07c16429";
const url7 =
  "https://www.flipkart.com/infinix-smart-hd-2021-quartz-green-32-gb/p/itm14159edd6bd3d?pid=MOBFY7MZTGYEA4HT&lid=LSTMOBFY7MZTGYEA4HTCRGN7T&marketplace=FLIPKART&q=mobiles&store=tyy%2F4io&srno=s_2_27&otracker=AS_Query_TrendingAutoSuggest_1_0_na_na_na&otracker1=AS_Query_TrendingAutoSuggest_1_0_na_na_na&fm=SEARCH&iid=d597331c-e95a-41b3-b4f0-07d83ea686be.MOBFY7MZTGYEA4HT.SEARCH&ppt=sp&ppn=sp&qH=eb4af0bf07c16429";
const url8 =
  "https://www.flipkart.com/nokia-ta-1174-ta-1299/p/itm5f8b39d15e2a3?pid=MOBEWXFKUAXUKQQA&lid=LSTMOBEWXFKUAXUKQQAAPLQRW&marketplace=FLIPKART&q=mobiles&store=tyy%2F4io&srno=s_2_34&otracker=AS_Query_TrendingAutoSuggest_1_0_na_na_na&otracker1=AS_Query_TrendingAutoSuggest_1_0_na_na_na&fm=SEARCH&iid=d597331c-e95a-41b3-b4f0-07d83ea686be.MOBEWXFKUAXUKQQA.SEARCH&ppt=sp&ppn=sp&qH=eb4af0bf07c16429";
const url9 =
  "https://www.flipkart.com/lava-a3/p/itma768345a8b2ca?pid=MOBFFTG39EVNDGH8&lid=LSTMOBFFTG39EVNDGH8XSEZM3&marketplace=FLIPKART&q=mobiles&store=tyy%2F4io&srno=s_2_36&otracker=AS_Query_TrendingAutoSuggest_1_0_na_na_na&otracker1=AS_Query_TrendingAutoSuggest_1_0_na_na_na&fm=SEARCH&iid=d597331c-e95a-41b3-b4f0-07d83ea686be.MOBFFTG39EVNDGH8.SEARCH&ppt=sp&ppn=sp&qH=eb4af0bf07c16429";
const url10 =
  "https://www.flipkart.com/poco-x3-pro-graphite-black-128-gb/p/itm736059fa07afb?pid=MOBGFKNFRJDN3DS4&lid=LSTMOBGFKNFRJDN3DS4PPS28U&marketplace=FLIPKART&q=mobiles&store=tyy%2F4io&srno=s_2_38&otracker=AS_Query_TrendingAutoSuggest_1_0_na_na_na&otracker1=AS_Query_TrendingAutoSuggest_1_0_na_na_na&fm=SEARCH&iid=d597331c-e95a-41b3-b4f0-07d83ea686be.MOBGFKNFRJDN3DS4.SEARCH&ppt=sp&ppn=sp&qH=eb4af0bf07c16429";

const arr = [url1, url2, url3, url4, url5, url6, url7, url8, url9, url10];

const userData = [];
async function pushArr(x) {
  for (const element of x) {
    const { data } = await axios.get(element);
    const $ = cheerio.load(data);
    
    const newData = new Datas({
        title: $('h1[class="yhB1nd"]').text(),
        price: $('div[class="_30jeq3 _16Jk6d"]').html(),
        image: $(
          "#container > div > div._2c7YLP.UtUXW0._6t1WkM._3HqJxg > div._1YokD2._2GoDe3 > div._1YokD2._3Mn1Gg.col-5-12._78xt5Y > div:nth-child(1) > div > div._3li7GG > div._1BweB8 > div._3kidJX > div.CXW8mj._3nMexc > img"
        ).attr().src,
        rating: $('div[class="_2d4LTz"]').text(),
      });
    newData.save();
  }
 
}
pushArr(arr);
const dataRoutes = require("./routes/dataRoute");
app.use("/user",dataRoutes);


app.listen(PORT, () => console.log("The server is started in " + PORT));