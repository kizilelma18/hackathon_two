
import { useEffect,useState } from "react";
import { makeStyles } from '@material-ui/core/styles';

import Card from '@material-ui/core/Card';
import CardHeader from '@material-ui/core/CardHeader';
import CardMedia from '@material-ui/core/CardMedia';
import CardContent from '@material-ui/core/CardContent';

import Typography from '@material-ui/core/Typography';

import "./App.css";
const useStyles = makeStyles((theme) => ({
  root: {
    width: "300px",
    "box-shadow": "0px 10px 10px 0px rgba(0,0,0,.5)",

    margin: "10px 25px",
  },
  media: {
    height: 0,
    paddingTop: '56.25%', // 16:9
  }
  
}));

function App() {
  const classes = useStyles();
  const [users,setUsers]= useState([])
  function getUsers() {
    console.log("User is mounted");
    fetch("http://localhost:5000/user", {
      method: "GET"
    })
      .then((res) => res.json())
      .then((res) => setUsers(res));
  }
  useEffect(() => getUsers(), []);
  
  return (
    <div className="App">
     
      <div className="recipe__wrapper container">
     
{users.map((user,i)=>(
  <Card id="hove"className={classes.root}>
  <CardHeader
    
    title={user.title}
    subheader="September 14, 2016"
  />
  <CardMedia
    className={classes.media}
    image={user.image}
    
  />
  <CardContent>
    <Typography variant="body2" color="textSecondary" component="p">
      {user.price}
    </Typography>
  </CardContent>

</Card>
))}
      
    </div>
    </div>
  );
}

export default App;
